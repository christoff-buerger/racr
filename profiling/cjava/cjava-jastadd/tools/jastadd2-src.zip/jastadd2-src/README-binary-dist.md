JastAdd2
========

JastAdd2 was developed at Lund University by Torbj&ouml;rn Ekman, G&ouml;rel
Hedin, and Eva Magnusson. JastAdd2 has recieved additional contributions from
Emma S&ouml;derberg, Jesper &Ouml;qvist and Niklas Fors.

For additional contributors, see the change logs.

License
-------

Copyright (c) 2005-2013, The JastAdd Team. All rights reserved.

JastAdd2 is covered by the modified BSD License. For the full license text
see the LICENSE file.

Obtaining JastAdd2
------------------

The latest version of JastAdd2 can be found at [jastadd.org](http://jastadd.org).

JavaCC
------

The context-free grammar used in JastAdd is based on an example from JavaCC, for the
full license text for JavaCC, see licenses/. 
